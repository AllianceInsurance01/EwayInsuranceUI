import { Component, OnInit } from '@angular/core';
import { MenuItem, MessageService } from 'primeng/api';

@Component({
  selector: 'app-customer-create-form',
  templateUrl: './customer-create-form.component.html',
  styles : [`.card .form-container div {
    min-width: 280px;
  }
  .card .form-container div label {
    font-weight: bold;
  }`],
  providers: [MessageService]
})
export class CustomerCreateFormComponent implements OnInit {
  items:MenuItem[] | undefined;
  customerTypes:any[] | undefined;
  currentCustomerType:any = 'personal';

  constructor(private messageService: MessageService) {}

  ngOnInit(): void {
    this.customerTypes = [{label: 'Personal', value: 'personal'}, {label: 'Corporate', value: 'corporate'}];
    this.items = [{ label: 'Home', routerLink:'/' }, {label:'Customer', routerLink: '/customer'}, { label: 'Create' }];
  }

  submit() {
    this.messageService.add({ severity: 'success', summary: 'Success', detail: 'Customer Added Successfully' });
  }
}
