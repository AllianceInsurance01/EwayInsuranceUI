import { Component, OnInit } from '@angular/core';
import { MenuItem } from 'primeng/api';

@Component({
  selector: 'app-customer-table',
  templateUrl: './customer-table.component.html',
  styles: [] 
})

export class CustomerTableComponent implements OnInit{
  items: MenuItem[] | undefined;
  tableActions:MenuItem[] | undefined;

  ngOnInit() {
    this.items = [{ label: 'Home', routerLink:'/' }, {label:'Customer'}];
    this.tableActions = [{label:'View'}, {label:'Edit'}, {label: 'delete'}];
  }

  columns:string[] = [
    '-',
      'Reference No', 
      'Customer No', 
      'Category', 
      'VrTin No', 
      'Mobile No', 
      'Email Address', 
      'Created By', 
      'Status'
    ];
    allCustomers:any[] = [{referenceNo:'123'}, {referenceNo:'123'},{referenceNo:'123'},{referenceNo:'123'},{referenceNo:'123'},{referenceNo:'123'}];
}
