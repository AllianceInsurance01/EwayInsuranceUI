import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VehicleCreateFormComponent } from './vehicle-create-form.component';

describe('VehicleCreateFormComponent', () => {
  let component: VehicleCreateFormComponent;
  let fixture: ComponentFixture<VehicleCreateFormComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [VehicleCreateFormComponent]
    });
    fixture = TestBed.createComponent(VehicleCreateFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
