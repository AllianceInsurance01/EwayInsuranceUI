import { Component, OnInit } from '@angular/core';
import { MenuItem, MessageService } from 'primeng/api';

@Component({
  selector: 'app-vehicle-create-form',
  templateUrl: './vehicle-create-form.component.html',
  styles : [`.card .form-container div {
    min-width: 280px;
  }
  .card .form-container div label {
    font-weight: bold;
  }`],
  providers: [MessageService]
})
export class VehicleCreateFormComponent implements OnInit {
  items:MenuItem[] | undefined;
  customerTypes:any[] | undefined;
  currentCustomerType:any = 'personal';

  constructor(private messageService: MessageService) {}

  ngOnInit(): void {
    this.customerTypes = [{label: 'Personal', value: 'personal'}, {label: 'Corporate', value: 'corporate'}];
    this.items = [{ label: 'Home', routerLink:'/' }, {label:'Vehicle', routerLink: '/vehicle'}, { label: 'Add Vehicle Details' }];
  }

  submit() {
    this.messageService.add({ severity: 'success', summary: 'Success', detail: 'Vehicle Added Successfully' });
  }
}
