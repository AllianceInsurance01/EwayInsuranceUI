import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { DashboardComponent } from './dashboard.component';
import { CustomerTableComponent } from '../customer/customer-table/customer-table.component';
import { CustomerCreateFormComponent } from '../customer/customer-create-form/customer-create-form.component';
import { VehicleTableComponent } from '../vehicle/vehicle-table/vehicle-table.component';
import { VehicleCreateFormComponent } from '../vehicle/vehicle-create-form/vehicle-create-form.component';

@NgModule({
    imports: [RouterModule.forChild([
        { path: '', component: DashboardComponent },
        {path: 'customer', component: CustomerTableComponent},
        {path: 'customer/create', component: CustomerCreateFormComponent},
        {path: 'vehicle', component: VehicleTableComponent},
        {path: 'vehicle/create', component: VehicleCreateFormComponent},
    ])],
    exports: [RouterModule]
})
export class DashboardsRoutingModule { }
