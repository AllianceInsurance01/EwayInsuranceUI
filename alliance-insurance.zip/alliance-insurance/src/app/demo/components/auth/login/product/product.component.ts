import { Component, ElementRef, OnInit } from '@angular/core';

class Product {
  name:string = '';
  imageUrl:string = '';
}

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html'
})
export class ProductComponent implements OnInit {
  products:Product[];

  ngOnInit(): void {
    this.products = [
      {name:'Burglary', imageUrl:''},
      {name:'Corporte Plus', imageUrl:''},
      {name:'Domestic', imageUrl:''},
      {name:'Employer\'s liability', imageUrl:''},
      {name:'Cyber Insurance', imageUrl:''},
      {name:'Fire and Allied Perillis', imageUrl:''},
      {name:'Motor', imageUrl:''},
      {name:'Short term policy', imageUrl:''},
      {name:'Machinery Breakdown', imageUrl:''},
      {name:'Medical Malpractice', imageUrl:''},
      {name:'Money', imageUrl:''},
      {name:'Fiedility', imageUrl:''},
    ];
  }

  selectedProduct:string = '';

  

  selectProduct(product) {
    this.selectedProduct = product;
    console.log(product);
  }

  isSelectedProduct(product) {
    console.log(this.selectedProduct);
    return product == this.selectedProduct;
  }
}
