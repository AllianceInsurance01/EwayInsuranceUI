import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-branch',
  templateUrl: './branch.component.html'
})
export class BranchComponent implements OnInit {
  cities:any[] = [];
  selectedCity:String = '';

  ngOnInit(): void {
    this.cities = [{name:'Arusha'},{name:'Yens'}];
  }
}
