import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { LoginComponent } from './login.component';
import { ProductComponent } from './product/product.component';
import { FormComponent } from './form/form.component';
import { BranchComponent } from './branch/branch.component';

@NgModule({
    imports: [RouterModule.forChild([
        { 
            path: '', component: LoginComponent, 
            children:[
                { path: 'product', component: ProductComponent},
                { path: 'branch', component: BranchComponent},
                { path: '**', component: FormComponent},
            ]
        },
    ])],
    exports: [RouterModule]
})
export class LoginRoutingModule { }
