import { Component } from '@angular/core';

@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
})
export class FormComponent {
  valCheck: string[] = ['remember'];
  password!: string;
}
